package org.stringtree;

public interface Repository extends Fetcher, Storer {
    // this interface intentionally left blank
}