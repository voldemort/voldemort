package org.stringtree;

public interface Container {
    String CONTAINER = "fetcher.container";
    boolean contains(String name);
}