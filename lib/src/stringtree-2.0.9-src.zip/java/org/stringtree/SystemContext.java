package org.stringtree;

public interface SystemContext {
    static final String SYSTEM_CLASSUTILS = "system.classutils";
    static final String SYSTEM_CLASSLOADER = "system.classloader";
    static final String IMPORT_PACKAGES = "import.packages";
}
