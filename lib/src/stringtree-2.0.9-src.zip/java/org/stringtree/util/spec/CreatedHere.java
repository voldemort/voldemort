package org.stringtree.util.spec;

import java.util.Iterator;

public interface CreatedHere {
    Iterator iterator();
}
