package org.stringtree.util;

public interface ObjectToString {
    String convert(Object value);
}
