package org.stringtree.util;

public interface Proxy {
    Object getValue();
}