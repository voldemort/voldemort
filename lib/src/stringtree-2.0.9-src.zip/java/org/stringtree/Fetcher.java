package org.stringtree;

public interface Fetcher {
    Object getObject(String name);
}
