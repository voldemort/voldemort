package org.stringtree.data;

public interface DataReader {
	Object read(String data);
}
