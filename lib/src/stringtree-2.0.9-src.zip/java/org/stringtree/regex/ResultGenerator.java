package org.stringtree.regex;

public interface ResultGenerator {
	String result(Matcher matcher);
}