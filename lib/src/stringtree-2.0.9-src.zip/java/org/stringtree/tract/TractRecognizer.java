package org.stringtree.tract;

import java.io.File;

public interface TractRecognizer {
    boolean isTract(File file);
}
