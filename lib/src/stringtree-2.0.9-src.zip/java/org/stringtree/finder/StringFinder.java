package org.stringtree.finder;

public interface StringFinder extends ObjectFinder {
    String get(String name);
}
