package org.stringtree.finder;

import org.stringtree.Storer;

public interface ObjectKeeper extends ObjectFinder, Storer {
    // this interface intentionally left blank
}
