package org.stringtree.finder;

import org.stringtree.Storer;

public interface TractKeeper extends TractFinder, Storer {
    // this interface intentionally left blank
}
