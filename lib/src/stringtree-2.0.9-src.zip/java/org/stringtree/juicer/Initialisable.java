package org.stringtree.juicer;

import org.stringtree.Fetcher;

public interface Initialisable {
	public void init(Fetcher context);
}