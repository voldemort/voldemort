package org.stringtree.juicer;

public interface Rewindable {
	public void rewind();
}