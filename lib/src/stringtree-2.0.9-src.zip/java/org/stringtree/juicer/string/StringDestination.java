package org.stringtree.juicer.string;

public interface StringDestination {
	void connectSource(StringSource source);
}
