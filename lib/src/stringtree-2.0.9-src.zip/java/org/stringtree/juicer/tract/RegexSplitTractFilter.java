package org.stringtree.juicer.tract;

public class RegexSplitTractFilter extends RegexSplitReplaceTractFilter {
    
	public RegexSplitTractFilter(String pattern) {
		super(pattern, "");
	}
}
