package org.stringtree.juicer.tract;

public interface TractDestination {
	void connectSource(TractSource source);
}
