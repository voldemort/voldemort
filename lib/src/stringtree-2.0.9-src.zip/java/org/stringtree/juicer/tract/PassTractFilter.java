package org.stringtree.juicer.tract;

public class PassTractFilter extends BasicTractFilter {
	// this class intentionally left blank
}
