package org.stringtree.fetcher;

public class PrefixResourceFilter extends PrefixSuffixResourceFilter {
    
    public PrefixResourceFilter(String prefix) {
        super(prefix, "");
    }
}
