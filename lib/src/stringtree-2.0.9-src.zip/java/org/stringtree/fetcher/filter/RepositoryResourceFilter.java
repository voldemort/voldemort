package org.stringtree.fetcher.filter;

public interface RepositoryResourceFilter {
    String fullName(String localname);
}
