package org.stringtree.fetcher;

public class SuffixResourceFilter extends PrefixSuffixResourceFilter {
    
    public SuffixResourceFilter(String suffix) {
        super("", suffix);
    }
}
