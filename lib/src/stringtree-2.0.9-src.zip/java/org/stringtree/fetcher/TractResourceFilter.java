package org.stringtree.fetcher;

public class TractResourceFilter extends SuffixResourceFilter {
    
    public TractResourceFilter() {
        super(".tract");
    }
}
