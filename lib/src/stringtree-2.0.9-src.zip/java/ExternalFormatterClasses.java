public class ExternalFormatterClasses {
	org.stringtree.juicer.formatter.ExternalFormatter c1;
	org.stringtree.util.FileReadingUtils c2;
	org.stringtree.util.ResourceUtils c3;
		
	FilterLock c4;
	FilterReplace c5;
	ForceReplace c6;
	Join c7;
	Lock c8;
	Replace c9;
	Include c10;
}
