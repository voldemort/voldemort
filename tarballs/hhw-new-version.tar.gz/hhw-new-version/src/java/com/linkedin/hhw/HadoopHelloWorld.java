package com.linkedin.hhw;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import azkaban.common.utils.Props;

import com.linkedin.batch.serialization.AbstractJsonHadoopJob;
import com.linkedin.batch.serialization.JsonMapper;
import com.linkedin.batch.serialization.JsonReducer;
import com.linkedin.batch.serialization.OutputSchema;

/**
 * HadoopHelloWorld counts all LinkedIn members, grouped by country. If a
 * member's country is null, it will be skipped.
 * 
 * @author criccomi
 * 
 */
public class HadoopHelloWorld extends AbstractJsonHadoopJob {

	public HadoopHelloWorld(String name, Props props) {
		super(name, props);
	}

	@Override
	public void run() throws Exception {
		JobClient.runJob(createJobConf(HadoopHelloWorldMapper.class, HadoopHelloWorldReducer.class));
	}
	
	@OutputSchema(key="mapper.key.schema", value="mapper.value.schema")
	public static final class HadoopHelloWorldMapper extends JsonMapper {
		@Override
		public void mapObjects(Object key, Object value,
				OutputCollector<Object, Object> output, Reporter reporter)
				throws IOException {
			Map<String, Object> inMap = (Map<String, Object>)value;
			String country = (String)inMap.get("country");
			
			if(country != null) {
				output.collect(country, new Integer(1));
			}
		}
	}
	
	@OutputSchema(key="reducer.key.schema", value="reducer.value.schema")
	public static final class HadoopHelloWorldReducer extends JsonReducer {
		@Override
		public void reduceObjects(Object key, Iterator<Object> values,
				OutputCollector<Object, Object> collector, Reporter reporter)
				throws IOException {
			Map<String, Object> outMap = new HashMap<String, Object>();
			int cnt = 0;
			
			for(; values.hasNext(); ++cnt) {
				values.next();
			}
			
			outMap.put("country", key);
			outMap.put("cnt", cnt);
			
			collector.collect(key, outMap);
		}
	}

}
